'use strict';

// ─── CREDENTIALS (Demo) ───────────────────────────────────────
const CMS_CREDENTIALS = {
  email: 'admin@sharifgroup.ae',
  password: 'SharifCMS@2026',
  name: 'Sharif Group Administrator',
  role: 'Admin'
};

// ─── STORAGE KEYS ─────────────────────────────────────────────
const KEYS = {
  AUTH: 'sgcms_auth',
  HOMEPAGE: 'sgcms_homepage',
  CITIZENSHIP: 'sgcms_citizenship',
  RESIDENCY: 'sgcms_residency',
  BLOG: 'sgcms_blog',
  TEAM: 'sgcms_team',
  OFFICES: 'sgcms_offices',
  CONTACT: 'sgcms_contact',
  NAV: 'sgcms_navigation',
  LEGAL: 'sgcms_legal',
  SETTINGS: 'sgcms_settings',
  ABOUTUS: 'sgcms_aboutus'
};

// ─── AUTH ─────────────────────────────────────────────────────
const Auth = {
  login(email, password) {
    if (email.toLowerCase() === CMS_CREDENTIALS.email && password === CMS_CREDENTIALS.password) {
      sessionStorage.setItem(KEYS.AUTH, JSON.stringify({ email: CMS_CREDENTIALS.email, name: CMS_CREDENTIALS.name, role: CMS_CREDENTIALS.role, loginTime: new Date().toISOString() }));
      return { success: true };
    }
    return { success: false, error: 'Incorrect email or password.' };
  },
  logout() { sessionStorage.removeItem(KEYS.AUTH); window.location.href = 'index.html'; },
  getSession() { try { return JSON.parse(sessionStorage.getItem(KEYS.AUTH)); } catch { return null; } },
  isAuthenticated() { return !!this.getSession(); },
  requireAuth() { if (!this.isAuthenticated()) window.location.href = 'index.html'; }
};

// ─── STORE ────────────────────────────────────────────────────
const Store = {
  get(key) {
    try {
      const v = localStorage.getItem(key);
      if (!v) return null;
      let parsed = JSON.parse(v);
      if (typeof parsed === 'string') {
        const trimmed = parsed.trim();
        if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
          try { parsed = JSON.parse(trimmed); } catch(e) {}
        }
      }
      return parsed;
    } catch { return null; }
  },
  set(key, data) {
    if (typeof data === 'string') {
      const trimmed = data.trim();
      if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
        try { data = JSON.parse(trimmed); } catch(e) {}
      }
    }
    const serialized = JSON.stringify(data);
    try {
      localStorage.setItem(key, serialized);
    } catch (e) {
      if (e.name !== 'QuotaExceededError' && e.name !== 'NS_ERROR_DOM_QUOTA_REACHED') throw e;

      // ── QUOTA RECOVERY PASS 1: Purge stale _live mirror keys ──
      const liveKeys = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.endsWith('_live')) liveKeys.push(k);
      }
      liveKeys.forEach(k => { try { localStorage.removeItem(k); } catch(_) {} });

      try {
        localStorage.setItem(key, serialized);
        return;
      } catch (e2) { /* continue recovery */ }

      // ── QUOTA RECOVERY PASS 2: If saving blog, strip default/empty FAQs ──
      if (key === 'sgcms_blog' && Array.isArray(data)) {
        const EMPTY_FAQ = { q: '', a: '' };
        const stripped = data.map(b => {
          if (!b) return b;
          const out = { ...b };
          // Remove FAQs that are default placeholders (empty q/a or match known defaults)
          ['en', 'ar', 'fa', 'zh'].forEach(lang => {
            if (out[lang] && Array.isArray(out[lang].faqs)) {
              out[lang] = { ...out[lang], faqs: out[lang].faqs.filter(f => f && f.q && f.q.trim() && f.a && f.a.trim()) };
            }
          });
          if (Array.isArray(out.faqs)) {
            out.faqs = out.faqs.filter(f => f && f.q && f.q.trim() && f.a && f.a.trim());
          }
          return out;
        });
        try {
          localStorage.setItem(key, JSON.stringify(stripped));
          console.warn('[CMS Storage] QuotaExceededError: saved blog with FAQs stripped to fit localStorage.');
          return;
        } catch (e3) { /* continue recovery */ }
      }

      // ── QUOTA RECOVERY PASS 3: Clear old sgcms_published_manifest ──
      try { localStorage.removeItem('sgcms_published_manifest'); } catch(_) {}
      try {
        localStorage.setItem(key, serialized);
        return;
      } catch (e4) { /* continue recovery */ }

      // ── FINAL FALLBACK: Log and skip (don't crash the UI) ──
      console.error('[CMS Storage] QuotaExceededError: localStorage is full and recovery failed. Data for key "' + key + '" was NOT saved locally. Please publish to sync to server.', e);
    }
  },
  getOrDefault(key, def) { const v = this.get(key); return v !== null ? v : (typeof def === 'function' ? def() : JSON.parse(JSON.stringify(def))); }
};

// ─── SETTINGS ─────────────────────────────────────────────────
const Settings = {
  get() {
    return Store.getOrDefault(KEYS.SETTINGS, {
      openrouter_api_key: '',
      gemini_api_key: '',
      ai_provider: 'openrouter',
      site_name: 'Sharif Group',
      preview_url: ''
    });
  },
  set(data) {
    Store.set(KEYS.SETTINGS, data);
    try { saveData(KEYS.SETTINGS, data); } catch (e) {}
  },
  getOpenRouterKey() { return this.get().openrouter_api_key || ''; },
  getGeminiKey() { return this.get().gemini_api_key || ''; },
  getAiKey() { return this.getOpenRouterKey() || this.getGeminiKey(); },
  getAiProvider() {
    if (this.getOpenRouterKey()) return 'openrouter';
    if (this.getGeminiKey()) return 'gemini';
    return this.get().ai_provider || 'openrouter';
  }
};

// ─── AI TRANSLATION ENGINE (OpenRouter & Gemini) ───────────────
const AI = {
  LANG_NAMES: { en: 'English', ar: 'Arabic', fa: 'Farsi (Persian)', zh: 'Chinese (Simplified)' },

  async translate(text, targetLang, sourceLang = 'en') {
    if (!text || !String(text).trim()) return '';
    text = String(text).trim();
    if (targetLang === sourceLang) return text;

    const openrouterKey = Settings.getOpenRouterKey();
    const geminiKey = Settings.getGeminiKey();
    const provider = openrouterKey ? 'openrouter' : (geminiKey ? 'gemini' : '');
    const apiKey = openrouterKey || geminiKey || '';

    // 1. Attempt server-side PHP API backend first (uses OpenRouter, Gemini, or zero-config Google Translate)
    try {
      const res = await fetch('api/ai.php?action=translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider,
          api_key: apiKey,
          text,
          targetLang,
          sourceLang
        })
      });
      if (res.ok) {
        const json = await res.json();
        if (json && json.success && typeof json.translated === 'string' && json.translated.trim()) {
          return json.translated.trim();
        }
      }
    } catch (e) {
      // Proceed to direct browser fallback
    }

    // 2. Direct browser Google Translate GTX fallback (always works, zero key required)
    try {
      const tl = targetLang === 'fa' ? 'fa' : (targetLang === 'zh' ? 'zh-CN' : targetLang);
      const gtxUrl = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${encodeURIComponent(sourceLang)}&tl=${encodeURIComponent(tl)}&dt=t&q=${encodeURIComponent(text)}`;
      const gtxRes = await fetch(gtxUrl);
      if (gtxRes.ok) {
        const gtxData = await gtxRes.json();
        if (Array.isArray(gtxData) && Array.isArray(gtxData[0])) {
          const joined = gtxData[0].map(s => s[0]).join('');
          if (joined && joined.trim()) return joined.trim();
        }
      }
    } catch (e) {
      // Proceed to client AI key fallback
    }

    // 3. Client-side direct fallback if an API key is available
    if (apiKey) {
      const prompt = `You are a professional luxury translator for a premier investment migration, second citizenship, and residency advisory firm (Sharif Group, Dubai). Translate the following text from ${this.LANG_NAMES[sourceLang]} to ${this.LANG_NAMES[targetLang]}. Maintain a formal, premium, high-end advisory tone appropriate for ultra-high-net-worth clients. Return ONLY the translated text, nothing else.\n\nText:\n${text}`;

      if (provider === 'openrouter') {
        const openRouterModels = [
          'openrouter/free',
          'google/gemini-2.0-flash-exp:free',
          'meta-llama/llama-3.3-70b-instruct:free',
          'meta-llama/llama-3.1-8b-instruct:free',
          'mistralai/mistral-small-24b-instruct-2501:free',
          'google/gemini-2.0-flash-001',
          'openrouter/auto'
        ];

        for (const model of openRouterModels) {
          try {
            const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + apiKey,
                'HTTP-Referer': 'https://sharifgroup.ae',
                'X-Title': 'Sharif Group CMS'
              },
              body: JSON.stringify({
                model,
                messages: [{ role: 'user', content: prompt }]
              })
            });

            if (res.ok) {
              const data = await res.json();
              const content = data?.choices?.[0]?.message?.content?.trim();
              if (content) return content;
            }
          } catch (fetchErr) {}
        }
      } else {
        const geminiModels = ['gemini-2.0-flash', 'gemini-2.0-flash-lite', 'gemini-1.5-flash', 'gemini-1.5-flash-latest', 'gemini-1.5-pro'];
        for (const m of geminiModels) {
          try {
            const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${encodeURIComponent(apiKey)}`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'x-goog-api-key': apiKey
              },
              body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
            });
            if (res.ok) {
              const data = await res.json();
              const text = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
              if (text) return text;
            }
          } catch (fetchErr) {}
        }
      }
    }

    return text;
  },

  async translateAllFields(fields, targetLang, onProgress) {
    const results = {};
    for (let i = 0; i < fields.length; i++) {
      const f = fields[i];
      if (onProgress) onProgress(i + 1, fields.length, f.key);
      if (f.value && f.value.trim()) {
        results[f.key] = await this.translate(f.value, targetLang);
      } else {
        results[f.key] = '';
      }
    }
    return results;
  },

  sanitizeKey(key) {
    if (!key) return '';
    return String(key)
      .replace(/[\u200B-\u200D\uFEFF]/g, '')
      .replace(/^Bearer\s+/i, '')
      .replace(/^["'`]|["'`]$/g, '')
      .trim();
  },

  formatGeminiError(errMsg) {
    if (!errMsg) return 'Gemini API test failed. Check the key.';
    if (errMsg.includes('OAuth') || errMsg.includes('devconsole-project') || errMsg.includes('invalid authentication credentials') || errMsg.includes('ACCESS_TOKEN_TYPE_UNSUPPORTED')) {
      return 'You provided an OAuth Client ID or OAuth credential from Google Cloud Console instead of an API Key. Google Gemini requires an API key from Google AI Studio. Please generate a free key at aistudio.google.com/apikey (takes 10 seconds).';
    }
    return errMsg;
  },

  async testOpenRouterKey(apiKey) {
    if (!apiKey) return { success: false, error: 'No API key provided' };
    const cleanKey = this.sanitizeKey(apiKey);

    // Auto-detect Google Gemini key pasted into OpenRouter box
    if (cleanKey.startsWith('AIza') || cleanKey.startsWith('AQ.')) {
      const geminiTest = await this.testKey(cleanKey);
      if (geminiTest.success) {
        return {
          success: true,
          isGeminiKey: true,
          message: 'Detected Google Gemini API key. Valid and connected!'
        };
      }
      return geminiTest;
    }

    // 1. Direct check to OpenRouter official auth/key endpoint (Zero-credit, instant, CORS-enabled)
    try {
      const res = await fetch('https://openrouter.ai/api/v1/auth/key', {
        headers: {
          'Authorization': 'Bearer ' + cleanKey
        }
      });
      if (res.ok) {
        const json = await res.json().catch(() => null);
        return { success: true, data: json?.data };
      }
      if (res.status === 401 || res.status === 403) {
        const errJson = await res.json().catch(() => null);
        return { success: false, error: errJson?.error?.message || 'Invalid OpenRouter API Key' };
      }
    } catch(e) {}

    // 2. Try server-side PHP test (if running with Apache/cPanel)
    try {
      const res = await fetch('api/ai.php?action=test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ provider: 'openrouter', api_key: cleanKey })
      });
      if (res.ok) {
        const json = await res.json().catch(() => null);
        if (json && json.success) return { success: true, data: json.data };
        if (json && json.error) return { success: false, error: json.error };
      }
    } catch(e) {}

    // 3. Fallback check with chat completions
    const freeModels = ['openrouter/free', 'meta-llama/llama-3.3-70b-instruct:free', 'google/gemini-2.0-flash-exp:free', 'google/gemini-2.0-flash-001'];
    for (const model of freeModels) {
      try {
        const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + cleanKey,
            'HTTP-Referer': 'https://sharifgroup.ae',
            'X-Title': 'Sharif Group CMS'
          },
          body: JSON.stringify({
            model,
            messages: [{ role: 'user', content: 'Say "OK" in one word.' }]
          })
        });
        if (res.ok) return { success: true };
      } catch (err) {}
    }

    return { success: false, error: 'Unable to connect to OpenRouter. Please check your network or key.' };
  },

  async testKey(apiKey) {
    if (!apiKey) return { success: false, error: 'No API key provided' };
    const cleanKey = this.sanitizeKey(apiKey);

    // Auto-detect OpenRouter or OpenAI keys pasted into Gemini box
    if (cleanKey.startsWith('sk-')) {
      const openRouterTest = await this.testOpenRouterKey(cleanKey);
      if (openRouterTest.success) {
        return {
          success: true,
          isOpenRouterKey: true,
          message: 'Detected OpenRouter API key. Valid and connected!'
        };
      }
      return {
        success: false,
        error: 'This key starts with "sk-", which is an OpenRouter or OpenAI key. Google Gemini keys start with "AIza...". Please paste this key in the OpenRouter box above, or get a Gemini key from aistudio.google.com.'
      };
    }

    // Auto-detect Google Cloud OAuth Client IDs or secrets
    if (cleanKey.includes('.apps.googleusercontent.com') || cleanKey.startsWith('GOCSPX-') || cleanKey.startsWith('ya29.')) {
      return {
        success: false,
        isOAuthCredential: true,
        error: 'You pasted a Google Cloud OAuth Client ID / Secret instead of an API Key. Google Gemini requires an API Key from Google AI Studio. Please generate your free API key at aistudio.google.com/apikey.'
      };
    }

    // 1. Direct validation via official Google models endpoint (zero-credit, authoritative key check)
    try {
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(cleanKey)}`, {
        headers: {
          'x-goog-api-key': cleanKey
        }
      });
      if (res.ok) {
        const data = await res.json().catch(() => null);
        let foundModel = 'gemini-2.0-flash';
        if (data && data.models && Array.isArray(data.models)) {
          const flashModel = data.models.find(m => m.name && m.name.includes('flash') && m.supportedGenerationMethods && m.supportedGenerationMethods.includes('generateContent'));
          if (flashModel) {
            foundModel = flashModel.name.replace('models/', '');
          }
        }
        return { success: true, model: foundModel };
      }
      if (res.status === 400 || res.status === 401 || res.status === 403) {
        const errJson = await res.json().catch(() => null);
        if (errJson && errJson.error && errJson.error.message) {
          return { success: false, error: this.formatGeminiError(errJson.error.message) };
        }
      }
    } catch (e) {}

    // 2. Try server-side PHP test (if running with Apache/cPanel)
    try {
      const res = await fetch('api/ai.php?action=test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ provider: 'gemini', api_key: cleanKey })
      });
      if (res.ok) {
        const json = await res.json().catch(() => null);
        if (json && json.success) return { success: true, model: json.model };
        if (json && json.error) return { success: false, error: this.formatGeminiError(json.error) };
      }
    } catch(e) {}

    // 3. Fallback check using established Gemini models
    const geminiModels = ['gemini-2.0-flash', 'gemini-2.0-flash-lite', 'gemini-1.5-flash', 'gemini-1.5-flash-latest', 'gemini-1.5-pro'];
    let lastErr = 'Gemini API test failed';

    for (const m of geminiModels) {
      try {
        const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${encodeURIComponent(cleanKey)}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-goog-api-key': cleanKey
          },
          body: JSON.stringify({ contents: [{ parts: [{ text: 'Say "OK" in one word.' }] }] })
        });
        if (res.ok) {
          return { success: true, model: m };
        }
        const errJson = await res.json().catch(() => null);
        lastErr = errJson?.error?.message || `HTTP ${res.status}`;
        if (lastErr.includes('API key not valid') || lastErr.includes('API_KEY_INVALID')) break;
      } catch (err) {
        lastErr = err.message;
      }
    }

    return { success: false, error: this.formatGeminiError(lastErr) };
  }
};

// ─── DEFAULT DATA ─────────────────────────────────────────────
const DEFAULTS = {
  homepage: {
    hero: {
      en: {
        tagline: 'UPGRADE YOUR LIFE',
        headline: 'Welcome to Sharif Group',
        pathway_citizenship: 'Citizenship',
        pathway_residency: 'Residency',
        pathway_realestate: 'Real Estate',
        pathway_education: 'Educational Advisory',
        subheadline: 'Expert citizenship and residency by investment advisory. 100% government-approved. Business Bay, Dubai.',
        cta_primary: 'Book Free Consultation',
        cta_primary_link: 'contact/index.html',
        cta_secondary: 'Explore Programs',
        cta_secondary_link: 'citizenshipbyinvestment/index.html'
      },
      ar: {
        tagline: 'ارتقِ بحياتك',
        headline: 'مرحباً بكم في مجموعة شريف',
        pathway_citizenship: 'الجنسية',
        pathway_residency: 'الإقامة',
        pathway_realestate: 'العقارات',
        pathway_education: 'الاستشارات التعليمية',
        subheadline: 'استشارات متخصصة في الجنسية والإقامة عبر الاستثمار. معتمدة حكومياً. الخليج التجاري، دبي.',
        cta_primary: 'احجز استشارة مجانية',
        cta_primary_link: 'contact/index.html',
        cta_secondary: 'استكشف البرامج',
        cta_secondary_link: 'citizenshipbyinvestment/index.html'
      },
      fa: {
        tagline: 'زندگی خود را ارتقا دهید',
        headline: 'به شریف گروپ خوش آمدید',
        pathway_citizenship: 'شهروندی',
        pathway_residency: 'اقامت',
        pathway_realestate: 'املاک و مستغلات',
        pathway_education: 'مشاوره تحصیلی',
        subheadline: 'مشاوره تخصصی اخذ شهروندی و اقامت از طریق سرمایه‌گذاری. تأیید رسمی دولتی. بیزینس بی، دبی.',
        cta_primary: 'رزرو مشاوره رایگان',
        cta_primary_link: 'contact/index.html',
        cta_secondary: 'مشاهده برنامه‌ها',
        cta_secondary_link: 'citizenshipbyinvestment/index.html'
      },
      zh: {
        tagline: '升级您的生活',
        headline: '欢迎来到谢里夫集团',
        pathway_citizenship: '公民身份',
        pathway_residency: '居留权',
        pathway_realestate: '房地产投资',
        pathway_education: '教育咨询',
        subheadline: '专业公民身份及居留权投资咨询。100%政府认证。迪拜商业湾。',
        cta_primary: '预约免费咨询',
        cta_primary_link: 'contact/index.html',
        cta_secondary: '探索项目',
        cta_secondary_link: 'citizenshipbyinvestment/index.html'
      }
    },
    stats: [
      { value: '10+', label_en: 'Years of Experience', label_ar: 'سنوات من الخبرة', label_fa: 'سال تجربه', label_zh: '年行业经验' },
      { value: '1000+', label_en: 'Successful CBI Cases', label_ar: 'حالات جنسية ناجحة', label_fa: 'پرونده موفق شهروندی', label_zh: '成功入籍案例' },
      { value: '100+', label_en: 'Residency & Education Cases', label_ar: 'حالات إقامة وتعليم', label_fa: 'پرونده اقامت و تحصیلی', label_zh: '居留及教育案例' },
      { value: '450+', label_en: 'Families Relocated', label_ar: 'عائلة تم نقلها', label_fa: 'خانواده مستقر شده', label_zh: '已安居家庭' }
    ],
    about: {
      en: {
        badge: 'INTRODUCTION',
        heading: 'Our Story & Background:',
        subheading: 'Sharif Group',
        p1: 'Sharif Group is a trusted private consulting company based in Business Bay, Dubai. We help international clients and families secure legal second passports, residency visas, premium property investments, and student placements in top international universities.',
        p2: 'Our experienced team takes care of document preparation, background legal checks, and government clearance from start to finish, ensuring a straightforward, secure, and completely stress-free experience.',
        btn1_text: 'Read Our Story',
        btn1_link: 'aboutus/index.html',
        btn2_text: 'Book Consultation',
        btn2_link: 'contact/index.html'
      },
      ar: {
        badge: 'مقدمة',
        heading: 'قصتنا وخبراتنا:',
        subheading: 'مجموعة شريف',
        p1: 'مجموعة شريف هي شركة استشارات خاصة موثوقة مقرها في الخليج التجاري، دبي. نساعد العملاء والعائلات الدولية في الحصول على جواز سفر ثانٍ قانوني وتأشيرات الإقامة والاستثمارات العقارية الفاخرة.',
        p2: 'يتولى فريقنا ذو الخبرة إعداد المستندات والفحوصات القانونية والتخليص الحكومي من البداية إلى النهاية لضمان تجربة آمنة وسلسة تماماً.',
        btn1_text: 'اقرأ قصتنا',
        btn1_link: 'aboutus/index.html',
        btn2_text: 'احجز استشارة',
        btn2_link: 'contact/index.html'
      },
      fa: {
        badge: 'معرفی',
        heading: 'داستان و پیشینه ما:',
        subheading: 'شریف گروپ',
        p1: 'شریف گروپ یک شرکت مشاوره خصوصی معتبر مستقر در بیزینس بی دبی است. ما به مشتریان و خانواده‌های بین‌المللی در دریافت پاسپورت دوم قانونی، ویزای اقامت، سرمایه‌گذاری املاک لوکس و پذیرش دانشگاه‌های برتر کمک می‌کنیم.',
        p2: 'تیم مجرب ما تمامی مراحل آماده‌سازی مدارک، بررسی‌های حقوقی و مجوزهای دولتی را از صفر تا صد با اطمینان کامل و بدون دغدغه به انجام می‌رساند.',
        btn1_text: 'خواندن داستان ما',
        btn1_link: 'aboutus/index.html',
        btn2_text: 'رزرو مشاوره',
        btn2_link: 'contact/index.html'
      },
      zh: {
        badge: '关于我们',
        heading: '我们的故事与背景：',
        subheading: '谢里夫集团',
        p1: '谢里夫集团是一家总部位于迪拜商业湾的知名专业咨询公司。我们协助全球客户及家庭合法获取第二本护照、居留签证、优质房产投资及世界顶级大学留学名额。',
        p2: '我们经验丰富的团队全程负责文件整理、背景合规审查以及政府审批流程，确保全程透明、安全、省心。',
        btn1_text: '了解我们的故事',
        btn1_link: 'aboutus/index.html',
        btn2_text: '预约咨询',
        btn2_link: 'contact/index.html'
      }
    },
    services: {
      badge: 'FEATURED PATHWAYS',
      heading: 'Our Services &',
      heading_italic: 'Pathways',
      description: 'Sovereign dual citizenship, European golden visas, Dubai luxury property portfolios, and Ivy League academic guidance.',
      pillar_cbi: {
        pillar_badge: 'Pillar 01 • Passports',
        title: 'Citizenship by Investment',
        p1: 'Getting a second citizenship gives you and your family the legal right to hold an extra passport. This opens up doors for easy global travel without needing visas ahead of time.',
        p2: 'Our team handles all paperwork, background checks, and official submissions so you do not have to worry about complicated rules.',
        items: [
          { id: 'dominica', title: 'Dominica | Passport', desc: 'Safe and peaceful Caribbean island offering straightforward legal passport processing without travel or language tests.', link: 'programs/citizenshipbyinvestment/dominica/index.html' },
          { id: 'stkitts', title: 'St. Kitts & Nevis | Passport', desc: 'The oldest and most trusted citizenship by investment program in the world, active since 1984 with dependable asset security.', link: 'programs/citizenshipbyinvestment/stkitts/' },
          { id: 'antigua', title: 'Antigua & Barbuda | Passport', desc: 'The best and most cost-effective passport solution for large families, covering up to four members under one baseline fee.', link: 'programs/citizenshipbyinvestment/antiguaandbarbuda/' },
          { id: 'lucia', title: 'Saint Lucia | Passport', desc: 'Flexible financial options with government-guaranteed bond investments that are 100% refundable after 5 years.', link: 'programs/citizenshipbyinvestment/stlucia/' },
          { id: 'grenada', title: 'Grenada | Passport', desc: 'Powerful second passport providing direct qualification to apply for the USA E-2 Investor Visa to live and conduct business in America.', link: 'programs/citizenshipbyinvestment/grenada/' },
          { id: 'vanuatu', title: 'Vanuatu | Passport', desc: 'The fastest legal citizenship pathway worldwide, delivered in 45 days with 100% remote processing.', link: 'programs/citizenshipbyinvestment/vanuatu/index.html' },
          { id: 'saotome', title: 'São Tomé and Príncipe | Passport', desc: 'Exclusive African island destination offering complete privacy, tax efficiency, and quiet citizenship by investment routes.', link: 'programs/citizenshipbyinvestment/sao-tome-and-principe/index.html' },
          { id: 'nauru', title: 'Republic of Nauru | Passport', desc: 'Peaceful Pacific island citizenship offering zero residency requirements and straightforward remote management from Dubai.', link: 'programs/citizenshipbyinvestment/nauru/index.html' }
        ]
      },
      pillar_rbi: {
        pillar_badge: 'Pillar 02 • Residency',
        title: 'Residency by Investment',
        p1: 'Residency and Golden Visa programs allow you to live, work, and study in amazing countries like Portugal, Greece, Panama, and the UAE.',
        p2: 'We help you choose the best residency option based on your lifestyle and business goals. Our experts prepare all legal documents.',
        items: [
          { id: 'portugal', title: 'Portugal | Golden Visa', desc: 'European residency through regulated fund investments with a minimal 7 days per year stay requirement leading to EU citizenship.', link: 'programs/residencybyinvestment/portugal/index.html' },
          { id: 'greece', title: 'Greece | Golden Visa', desc: 'Permanent European residence cards and Schengen zone access granted through vetted real estate acquisitions.', link: 'programs/residencybyinvestment/greece/index.html' },
          { id: 'panama', title: 'Panama | Golden Visa', desc: 'International banking hub offering rapid permanent residency and complete offshore corporate tax exemptions.', link: 'programs/residencybyinvestment/panama/index.html' },
          { id: 'uae', title: 'United Arab Emirates | Golden Visa', desc: 'Secure 10-year residency for you and your family with zero personal income tax, world-class infrastructure, and direct Dubai clearing lanes.', link: 'programs/residencybyinvestment/uae/index.html' }
        ]
      },
      pillar_uae: {
        pillar_badge: 'Pillar 03 • Dubai Direct',
        title: 'UAE 10-Year Golden Visa',
        p1: 'The UAE Golden Visa gives investors, entrepreneurs, and skilled professionals the right to live in Dubai for 10 long years without needing a local sponsor.',
        p2: 'Our office in Business Bay, Dubai works directly with government authorities and the Dubai Land Department.',
        btn_text: 'View UAE Process',
        btn_link: 'programs/residencybyinvestment/uae/index.html'
      },
      pillar_realestate: {
        pillar_badge: 'Pillar 04 • Property Desk',
        title: 'Prime Real Estate Advisory',
        p1: 'Investing in real estate is one of the smartest ways to grow your wealth while securing a path to residency.',
        p2: 'Before you buy any property, our legal team checks all land titles, builder histories, and payment plans.',
        btn_text: 'Explore Properties',
        btn_link: 'realestate/index.html'
      },
      pillar_education: {
        pillar_badge: 'Pillar 05 • Academic Board',
        title: 'Educational Advisory',
        p1: 'Giving your children the best education opens up a bright future for them. We help families secure student placements in top boarding schools and famous universities.',
        p2: 'By pairing your university applications with a second citizenship or global residency, your children can qualify for domestic tuition rates.',
        btn_text: 'View Academic Advisory',
        btn_link: 'educationaladvisory/index.html'
      }
    },
    social_responsibility: {
      badge: 'COMMUNITY IMPACT & CHARITY',
      heading: 'Our Commitment to',
      heading_italic: 'Social Responsibility',
      description: 'Beyond global advisory, Sharif Group actively supports educational initiatives, vulnerable family assistance, and sustainable community developments.',
      btn_text: 'Explore Our Initiatives',
      btn_link: 'socialresponsibility/index.html'
    },
    reviews: {
      badge: 'CLIENT REVIEWS',
      heading: 'Success Stories',
      slides: [
        { id: 'r1', quote: '"Fast follow-up and straightforward documentation."', btn_text: 'Start Your Journey Now', btn_link: 'contact/index.html', img: 'clients/client1.png' },
        { id: 'r2', quote: '"Reliable advice based on real experience."', btn_text: 'Start Your Journey Now', btn_link: 'contact/index.html', img: 'clients/client2.jpg' },
        { id: 'r3', quote: '"Professional, structured, and transparent throughout."', btn_text: 'Start Your Journey Now', btn_link: 'contact/index.html', img: 'clients/client3.jpg' },
        { id: 'r4', quote: '"Great communication and support until approval."', btn_text: 'Start Your Journey Now', btn_link: 'contact/index.html', img: 'clients/client4.png' },
        { id: 'r5', quote: '"Extremely efficient process from start to finish."', btn_text: 'Start Your Journey Now', btn_link: 'contact/index.html', img: 'clients/client5.jpeg' },
        { id: 'r6', quote: '"Clear expectations and seamless delivery."', btn_text: 'Start Your Journey Now', btn_link: 'contact/index.html', img: 'clients/client6.jpeg' },
        { id: 'r7', quote: '"Exceptional guidance and advisory every step of the way."', btn_text: 'Start Your Journey Now', btn_link: 'contact/index.html', img: 'clients/client7.jpeg' }
      ]
    },
    contact_block: {
      badge: 'GET IN TOUCH',
      heading: 'Book a Free Consultation',
      subheading: 'Speak directly with our expert team in Dubai',
      office_label: 'Our Office',
      office_address: '116, The Binary Tower, Business Bay, Dubai, UAE',
      phone_label: 'Phone Number',
      phone: '+971 4 357 8737',
      email_label: 'Email Address',
      email: 'contact@sharifgroup.ae'
    }
  },
  citizenship: [
    {
      id: 'dominica',
      slug: 'dominica',
      flag: 'https://flagcdn.com/dm.svg',
      portfolio: 'caribbean',
      nav_visible: true,
      nav_sort: 1,
      status: 'published',
      en: {
        title: 'Dominica Citizenship by Investment',
        nav_label: 'Dominica | Passport',
        hero_subtitle: 'Citizenship By Investment',
        investment_from: '$200,000 USD',
        processing_time: '6–9 Months',
        visa_free: '140+',
        overview_title: "Program Overview: Sharif Group's Guide",
        overview: "Dominica, known as the beautiful Nature Isle of the Caribbean, offers one of the most reliable and efficient second passport programs in the world. With quick processing speeds and a secure legal foundation, this program grants high-net-worth investors and their families instant global mobility. Our Business Bay firm guides your family securely from start to finish.",
        badges: [
          'Fully Remote, No Presence Requirements',
          '6-9 Months Time To Passport',
          'Contribution Starting from $200,000',
          '2 Investment Routes',
          '16+ Mandatory Interview Age'
        ],
        specs: [
          { title: 'PROCESSING TIME', desc: 'Approximately 6-9 months to complete' },
          { title: 'VISA-FREE TRAVEL', desc: 'Access to over 140+ countries worldwide' },
          { title: 'INVESTMENT TYPE', desc: 'Choose from economic donation or approved real estate' },
          { title: 'INVESTMENT COST', desc: 'USD 200,000 for single or USD 250,000 for family of 4' },
          { title: 'FAMILY DEPENDENTS', desc: 'Includes spouse, dependent children under 30, and dependent parents or grandparents above 65 years old' }
        ],
        benefits: [
          { title: 'Efficient Processing', desc: 'Citizenship achievable within 5 to 8 months.' },
          { title: 'Global Access', desc: 'Visa-free access to over 132 countries including the EU and UK.' },
          { title: 'Investment Flexibility', desc: 'Invest only after application approval, with options including donations or real estate.' },
          { title: 'Advantageous Tax Conditions', desc: 'Enjoy no taxation on worldwide income, gifts, wealth, or inheritance.' },
          { title: 'Inclusive Family Benefits', desc: 'Include dependent children under 30, unmarried daughters under 30, and dependent parents over 55.' },
          { title: 'Dual Citizenship', desc: 'Permitted without the need to renounce your current nationality.' },
          { title: 'Extended UK Stays', desc: 'Stay in the UK for up to 6 months at a time.' },
          { title: 'Flexible Residency Requirements', desc: 'Acquire citizenship without mandatory residency in Dominica.' }
        ],
        investment_options: [
          { title: '1. Economic Diversification Fund (EDF)', desc: 'Sovereign non-refundable contribution starting from $200,000 USD for a single applicant.' },
          { title: '2. Approved Real Estate Investment', desc: 'Purchase government-approved luxury resort or eco-villa shares starting from $200,000 USD.' }
        ],
        faqs: [
          { q: 'How long does the Dominica citizenship process take?', a: 'The typical timeline is 6 to 9 months from initial document submission to passport issuance.' },
          { q: 'Do I need to visit or reside in Dominica?', a: 'No, Dominica does not require any physical presence or residency before or after citizenship is granted.' }
        ]
      },
      ar: {
        title: 'الجنسية الدومينيكية عن طريق الاستثمار',
        nav_label: 'دومينيكا | جواز سفر',
        hero_subtitle: 'الجنسية عن طريق الاستثمار',
        investment_from: '$200,000 USD',
        processing_time: '6-9 أشهر',
        visa_free: '+140',
        overview_title: 'نظرة عامة على البرنامج: دليل مجموعة شريف',
        overview: 'تقدم دومينيكا، المعروفة بجزيرة الطبيعة في البحر الكاريبي، أحد أكثر برامج جوازات السفر الثانية موثوقية وكفاءة في العالم.',
        badges: ['عن بعد بالكامل، دون متطلبات حضور', '6-9 أشهر للحصول على الجواز', 'مساهمة تبدأ من 200,000 دولار', 'مساران استثماريان'],
        specs: [],
        benefits: [],
        investment_options: [],
        faqs: []
      },
      fa: {
        title: 'شهروندی دومینیکا از طریق سرمایه‌گذاری',
        nav_label: 'دومینیکا | پاسپورت',
        hero_subtitle: 'شهروندی از طریق سرمایه‌گذاری',
        investment_from: '$200,000 USD',
        processing_time: '۶ تا ۹ ماه',
        visa_free: '+۱۴۰',
        overview_title: 'بررسی جامع برنامه: راهنمای شریف گروپ',
        overview: 'دومینیکا یکی از پایدارترین و معتبرترین برنامه‌های شهروندی از طریق سرمایه‌گذاری را ارائه می‌دهد.',
        badges: ['کاملاً غیرحضوری، بدون نیاز به اقامت', '۶ تا ۹ ماه تا صدور پاسپورت', 'شروع از ۲۰۰ هزار دلار', '۲ روش سرمایه‌گذاری'],
        specs: [],
        benefits: [],
        investment_options: [],
        faqs: []
      },
      zh: {
        title: '多米尼克投资入籍项目',
        nav_label: '多米尼克 | 护照',
        hero_subtitle: '投资入籍项目',
        investment_from: '$200,000美元',
        processing_time: '6-9个月',
        visa_free: '140+',
        overview_title: '项目概览：谢里夫集团指南',
        overview: '多米尼克被誉为加勒比海的“自然之岛”，提供全球最成熟且高效的第二护照投资入籍项目之一。',
        badges: ['全程远程办理，无居住要求', '6-9个月获发护照', '投资起价20万美元', '2种投资途径'],
        specs: [],
        benefits: [],
        investment_options: [],
        faqs: []
      }
    },
    {
      id: 'stkitts',
      slug: 'stkitts',
      flag: 'https://flagcdn.com/kn.svg',
      portfolio: 'caribbean',
      nav_visible: true,
      nav_sort: 2,
      status: 'published',
      en: {
        title: 'St. Kitts & Nevis Citizenship by Investment',
        nav_label: 'St. Kitts & Nevis | Passport',
        hero_subtitle: 'Citizenship By Investment',
        investment_from: '$250,000 USD',
        processing_time: '3–6 Months',
        visa_free: '155+',
        overview: 'The oldest citizenship by investment program in the world, offering a prestigious passport and tax-free living since 1984.',
        benefits: [
          { title: 'Oldest CBI Program', desc: 'Established in 1984 with trusted global standing.' },
          { title: 'Visa-Free Access', desc: '155+ countries worldwide without advance visas.' }
        ],
        faqs: []
      },
      ar: { title: 'جنسية سانت كيتس ونيفيس', hero_subtitle: 'الجنسية عن طريق الاستثمار', nav_label: 'سانت كيتس | جواز سفر', investment_from: '$250,000', processing_time: '3-6 أشهر', visa_free: '+155', overview: '', benefits: [], faqs: [] },
      fa: { title: 'شهروندی سنت کیتس و نویس', hero_subtitle: 'شهروندی از طریق سرمایه‌گذاری', nav_label: 'سنت کیتس | پاسپورت', investment_from: '$250,000', processing_time: '۳ تا ۶ ماه', visa_free: '+۱۵۵', overview: '', benefits: [], faqs: [] },
      zh: { title: '圣基茨和尼维斯投资入籍', hero_subtitle: '投资入籍', nav_label: '圣基茨 | 护照', investment_from: '$250,000', processing_time: '3-6个月', visa_free: '155+', overview: '', benefits: [], faqs: [] }
    },
    {
      id: 'antigua',
      slug: 'antigua',
      flag: 'https://flagcdn.com/ag.svg',
      portfolio: 'caribbean',
      nav_visible: true,
      nav_sort: 3,
      status: 'published',
      en: {
        title: 'Antigua & Barbuda Citizenship by Investment',
        nav_label: 'Antigua & Barbuda | Passport',
        hero_subtitle: 'Citizenship By Investment',
        investment_from: '$100,000 USD',
        processing_time: '3–5 Months',
        visa_free: '150+',
        overview: 'Affordable Caribbean citizenship with excellent global mobility and family inclusion.',
        benefits: [
          { title: 'Best for Families', desc: 'Cost-effective for families up to 4 members.' }
        ],
        faqs: []
      },
      ar: { title: 'جنسية أنتيغوا وبربودا', hero_subtitle: 'الجنسية عن طريق الاستثمار', nav_label: 'أنتيغوا | جواز سفر', investment_from: '$100,000', processing_time: '3-5 أشهر', visa_free: '+150', overview: '', benefits: [], faqs: [] },
      fa: { title: 'شهروندی آنتیگوا و باربودا', hero_subtitle: 'شهروندی از طریق سرمایه‌گذاری', nav_label: 'آنتیگوا | پاسپورت', investment_from: '$100,000', processing_time: '۳ تا ۵ ماه', visa_free: '+۱۵۰', overview: '', benefits: [], faqs: [] },
      zh: { title: '安提瓜和巴布达投资入籍', hero_subtitle: '投资入籍', nav_label: '安提瓜 | 护照', investment_from: '$100,000', processing_time: '3-5个月', visa_free: '150+', overview: '', benefits: [], faqs: [] }
    },
    {
      id: 'stlucia',
      slug: 'stlucia',
      flag: 'https://flagcdn.com/lc.svg',
      portfolio: 'caribbean',
      nav_visible: true,
      nav_sort: 4,
      status: 'published',
      en: {
        title: 'Saint Lucia Citizenship by Investment',
        nav_label: 'Saint Lucia | Passport',
        hero_subtitle: 'Citizenship By Investment',
        investment_from: '$240,000 USD',
        processing_time: '3–4 Months',
        visa_free: '140+',
        overview: 'Saint Lucia offers a modern, prestigious Caribbean citizenship program with rapid processing through the National Economic Fund, real estate, or government bonds.',
        benefits: [
          { title: 'Visa-Free Mobility', desc: 'Access 140+ countries visa-free including EU Schengen and UK.' },
          { title: 'Remote Processing', desc: 'Zero physical residency or visit required before or after approval.' }
        ],
        faqs: []
      },
      ar: { title: 'جنسية سانت لوسيا عبر الاستثمار', hero_subtitle: 'الجنسية عن طريق الاستثمار', nav_label: 'سانت لوسيا | جواز سفر', investment_from: '$240,000', processing_time: '3-4 أشهر', visa_free: '+140', overview: '', benefits: [], faqs: [] },
      fa: { title: 'شهروندی سنت لوسیا از طریق سرمایه‌گذاری', hero_subtitle: 'شهروندی از طریق سرمایه‌گذاری', nav_label: 'سنت لوسیا | پاسپورت', investment_from: '$240,000', processing_time: '۳ تا ۴ ماه', visa_free: '+۱۴۰', overview: '', benefits: [], faqs: [] },
      zh: { title: '圣卢西亚投资入籍', hero_subtitle: '投资入籍', nav_label: '圣卢西亚 | 护照', investment_from: '$240,000', processing_time: '3-4个月', visa_free: '140+', overview: '', benefits: [], faqs: [] }
    },
    {
      id: 'grenada',
      slug: 'grenada',
      flag: 'https://flagcdn.com/gd.svg',
      portfolio: 'caribbean',
      nav_visible: true,
      nav_sort: 5,
      status: 'published',
      en: {
        title: 'Grenada Citizenship by Investment',
        nav_label: 'Grenada | Passport',
        hero_subtitle: 'Citizenship By Investment',
        investment_from: '$150,000 USD',
        processing_time: '4–6 Months',
        visa_free: '140+',
        overview: 'Grenada is the only Caribbean CBI program with a US E-2 Investor Visa treaty, enabling holders to reside and run a business in the United States.',
        benefits: [
          { title: 'USA E-2 Treaty', desc: 'Direct qualification to apply for the US E-2 Investor Visa.' }
        ],
        faqs: []
      },
      ar: { title: 'جنسية غرينادا', hero_subtitle: 'الجنسية عن طريق الاستثمار', nav_label: 'غرينادا | جواز سفر', investment_from: '$150,000', processing_time: '4-6 أشهر', visa_free: '+140', overview: '', benefits: [], faqs: [] },
      fa: { title: 'شهروندی گرنادا', hero_subtitle: 'شهروندی از طریق سرمایه‌گذاری', nav_label: 'گرنادا | پاسپورت', investment_from: '$150,000', processing_time: '۴ تا ۶ ماه', visa_free: '+۱۴۰', overview: '', benefits: [], faqs: [] },
      zh: { title: '格林纳达投资入籍', hero_subtitle: '投资入籍', nav_label: '格林纳达 | 护照', investment_from: '$150,000', processing_time: '4-6个月', visa_free: '140+', overview: '', benefits: [], faqs: [] }
    },
    {
      id: 'vanuatu',
      slug: 'vanuatu',
      flag: 'https://flagcdn.com/vu.svg',
      portfolio: 'global',
      nav_visible: true,
      nav_sort: 1,
      status: 'published',
      en: {
        title: 'Vanuatu Citizenship by Investment',
        nav_label: 'Vanuatu | Passport',
        hero_subtitle: 'Citizenship By Investment',
        investment_from: '$130,000 USD',
        processing_time: '30–60 Days',
        visa_free: '130+',
        overview: "World's fastest citizenship by investment program — complete remote approval in as little as 30 to 45 days.",
        benefits: [
          { title: 'Fastest in World', desc: 'Complete passport delivery in 45 days.' }
        ],
        faqs: []
      },
      ar: { title: 'جنسية فانواتو', hero_subtitle: 'الجنسية عن طريق الاستثمار', nav_label: 'فانواتو | جواز سفر', investment_from: '$130,000', processing_time: '30-60 يوماً', visa_free: '+130', overview: '', benefits: [], faqs: [] },
      fa: { title: 'شهروندی وانواتو', hero_subtitle: 'شهروندی از طریق سرمایه‌گذاری', nav_label: 'وانواتو | پاسپورت', investment_from: '$130,000', processing_time: '۳۰ تا ۶۰ روز', visa_free: '+۱۳۰', overview: '', benefits: [], faqs: [] },
      zh: { title: '瓦努阿图投资入籍', hero_subtitle: '投资入籍', nav_label: '瓦努阿图 | 护照', investment_from: '$130,000', processing_time: '30-60天', visa_free: '130+', overview: '', benefits: [], faqs: [] }
    },
    {
      id: 'saotome',
      slug: 'sao-tome-and-principe',
      flag: 'https://flagcdn.com/st.svg',
      portfolio: 'global',
      nav_visible: true,
      nav_sort: 2,
      status: 'published',
      en: {
        title: 'São Tomé & Príncipe Citizenship by Investment',
        nav_label: 'São Tomé and Príncipe | Passport',
        hero_subtitle: 'Citizenship By Investment',
        investment_from: '$100,000 USD',
        processing_time: '2–3 Months',
        visa_free: '90+',
        overview: 'Official African island nation CBI offering fast-track dual citizenship, attractive tax neutrality, and emerging global mobility for forward-looking investors.',
        benefits: [
          { title: 'Affordable Entry', desc: 'Starting from $100,000 for single applicant.' },
          { title: 'Fast-Track Delivery', desc: 'Passport issued within 60 to 90 days with zero physical stay.' }
        ],
        faqs: []
      },
      ar: { title: 'جنسية ساو تومي وبرينسيبي', hero_subtitle: 'الجنسية عن طريق الاستثمار', nav_label: 'ساو تومي | جواز سفر', investment_from: '$100,000', processing_time: '2-3 أشهر', visa_free: '+90', overview: '', benefits: [], faqs: [] },
      fa: { title: 'شهروندی سائوتومه و پرنسیپ', hero_subtitle: 'شهروندی از طریق سرمایه‌گذاری', nav_label: 'سائوتومه | پاسپورت', investment_from: '$100,000', processing_time: '۲ تا ۳ ماه', visa_free: '+۹۰', overview: '', benefits: [], faqs: [] },
      zh: { title: '圣多美和普林西比投资入籍', hero_subtitle: '投资入籍', nav_label: '圣多美 | 护照', investment_from: '$100,000', processing_time: '2-3个月', visa_free: '90+', overview: '', benefits: [], faqs: [] }
    },
    {
      id: 'nauru',
      slug: 'nauru',
      flag: 'https://flagcdn.com/nr.svg',
      portfolio: 'global',
      nav_visible: true,
      nav_sort: 3,
      status: 'published',
      en: {
        title: 'Republic of Nauru Citizenship by Investment',
        nav_label: 'Republic of Nauru | Passport',
        hero_subtitle: 'Citizenship By Investment',
        investment_from: '$105,000 USD',
        processing_time: '3–4 Months',
        visa_free: '89+',
        overview: 'Official Pacific Climate Resilience citizenship by investment program granting rapid global mobility, remote filing from Dubai, and Commonwealth heritage privileges.',
        benefits: [
          { title: 'Climate Innovation Fund', desc: 'Government-backed contribution with strong international backing.' },
          { title: 'Zero Physical Presence', desc: 'Entire process handled securely through Sharif Group Business Bay.' }
        ],
        faqs: []
      },
      ar: { title: 'جنسية جمهورية ناورو', hero_subtitle: 'الجنسية عن طريق الاستثمار', nav_label: 'جمهورية ناورو | جواز سفر', investment_from: '$105,000', processing_time: '3-4 أشهر', visa_free: '+89', overview: '', benefits: [], faqs: [] },
      fa: { title: 'شهروندی جمهوری نائورو', hero_subtitle: 'شهروندی از طریق سرمایه‌گذاری', nav_label: 'جمهوری نائورو | پاسپورت', investment_from: '$105,000', processing_time: '۳ تا ۴ ماه', visa_free: '+۸۹', overview: '', benefits: [], faqs: [] },
      zh: { title: '瑙鲁共和国投资入籍', hero_subtitle: '投资入籍', nav_label: '瑙鲁共和国 | 护照', investment_from: '$105,000', processing_time: '3-4个月', visa_free: '89+', overview: '', benefits: [], faqs: [] }
    }
  ],
  residency: [
    {
      id: 'portugal',
      slug: 'portugal',
      flag: 'https://flagcdn.com/pt.svg',
      portfolio: 'european',
      nav_visible: true,
      nav_sort: 1,
      status: 'published',
      en: {
        title: 'Portugal Golden Visa',
        nav_label: 'Portugal | Golden Visa',
        hero_subtitle: 'Residency By Investment',
        investment_from: '€500,000 EUR',
        processing_time: '6–12 Months',
        overview: 'Portugal Golden Visa offers European residency with a pathway to citizenship in 5 years and only 7 days per year stay requirement.',
        benefits: [
          { title: 'EU Residency', desc: 'Full Schengen travel and residence rights.' }
        ],
        faqs: []
      },
      ar: { title: 'التأشيرة الذهبية البرتغالية', hero_subtitle: 'الإقامة عن طريق الاستثمار', nav_label: 'البرتغال | الذهبية', investment_from: '€500,000', processing_time: '6-12 شهراً', overview: '', benefits: [], faqs: [] },
      fa: { title: 'ویزای طلایی پرتغال', hero_subtitle: 'اقامت از طریق سرمایه‌گذاری', nav_label: 'پرتغال | ویزای طلایی', investment_from: '€500,000', processing_time: '۶ تا ۱۲ ماه', overview: '', benefits: [], faqs: [] },
      zh: { title: '葡萄牙黄金签证', hero_subtitle: '投资居留', nav_label: '葡萄牙 | 黄金签证', investment_from: '€500,000', processing_time: '6-12个月', overview: '', benefits: [], faqs: [] }
    },
    {
      id: 'greece',
      slug: 'greece',
      flag: 'https://flagcdn.com/gr.svg',
      portfolio: 'european',
      nav_visible: true,
      nav_sort: 2,
      status: 'published',
      en: {
        title: 'Greece Golden Visa',
        nav_label: 'Greece | Golden Visa',
        hero_subtitle: 'Residency By Investment',
        investment_from: '€250,000 EUR',
        processing_time: '3–6 Months',
        overview: 'Greece Golden Visa is among the most affordable EU residency programs granting permanent residence cards and Schengen zone access.',
        benefits: [
          { title: 'Affordable EU Residency', desc: 'Real estate investment from €250,000 with Schengen access.' }
        ],
        faqs: []
      },
      ar: { title: 'التأشيرة الذهبية اليونانية', hero_subtitle: 'الإقامة عن طريق الاستثمار', nav_label: 'اليونان | الذهبية', investment_from: '€250,000', processing_time: '3-6 أشهر', overview: '', benefits: [], faqs: [] },
      fa: { title: 'ویزای طلایی یونان', hero_subtitle: 'اقامت از طریق سرمایه‌گذاری', nav_label: 'یونان | ویزای طلایی', investment_from: '€250,000', processing_time: '۳ تا ۶ ماه', overview: '', benefits: [], faqs: [] },
      zh: { title: '希腊黄金签证', hero_subtitle: '投资居留', nav_label: '希腊 | 黄金签证', investment_from: '€250,000', processing_time: '3-6个月', overview: '', benefits: [], faqs: [] }
    },
    {
      id: 'panama',
      slug: 'panama',
      flag: 'https://flagcdn.com/pa.svg',
      portfolio: 'uae',
      nav_visible: true,
      nav_sort: 3,
      status: 'published',
      en: {
        title: 'Panama Golden Visa & Permanent Residency',
        nav_label: 'Panama | Golden Visa',
        hero_subtitle: 'Residency By Investment',
        investment_from: '$200,000 USD',
        processing_time: '30–60 Days',
        overview: 'Panama Qualified Investor Visa provides permanent residency in 30 days via real estate or bank deposits, complete territorial tax freedom, and a direct citizenship pathway.',
        benefits: [
          { title: '30-Day Permanent Residency', desc: 'Immediate permanent resident status for the whole family.' },
          { title: '0% Foreign Income Tax', desc: 'Territorial tax system ensures zero tax on offshore earnings.' }
        ],
        faqs: []
      },
      ar: { title: 'التأشيرة الذهبية لبنما', hero_subtitle: 'الإقامة عن طريق الاستثمار', nav_label: 'بنما | الذهبية', investment_from: '$200,000', processing_time: '30-60 يوماً', overview: '', benefits: [], faqs: [] },
      fa: { title: 'ویزای طلایی پاناما', hero_subtitle: 'اقامت از طریق سرمایه‌گذاری', nav_label: 'پاناما | ویزای طلایی', investment_from: '$200,000', processing_time: '۳۰ تا ۶۰ روز', overview: '', benefits: [], faqs: [] },
      zh: { title: '巴拿马黄金签证', hero_subtitle: '投资居留', nav_label: '巴拿马 | 黄金签证', investment_from: '$200,000', processing_time: '30-60天', overview: '', benefits: [], faqs: [] }
    },
    {
      id: 'uae',
      slug: 'uae',
      flag: 'https://flagcdn.com/ae.svg',
      portfolio: 'uae',
      nav_visible: true,
      nav_sort: 4,
      status: 'published',
      en: {
        title: 'United Arab Emirates Golden Visa',
        nav_label: 'United Arab Emirates | Golden Visa',
        hero_title: 'United Arab Emirates',
        hero_subtitle: 'Golden Visa',
        investment_from: 'AED 2,000,000',
        processing_time: '2–4 Weeks',
        overview: 'The UAE Golden Visa grants 10-year renewable residency to investors, property owners, and entrepreneurs with zero personal income tax.',
        benefits: [
          { title: '10-Year Renewable', desc: 'Long-term stability in Dubai without local sponsor requirements.' }
        ],
        faqs: []
      },
      ar: { title: 'الإقامة الذهبية الإماراتية 10 سنوات', hero_subtitle: 'التأشيرة الذهبية', nav_label: 'الإمارات | الذهبية', investment_from: 'AED 2,000,000', processing_time: '2-4 أسابيع', overview: '', benefits: [], faqs: [] },
      fa: { title: 'ویزای طلایی ۱۰ ساله امارات', hero_subtitle: 'ویزای طلایی', nav_label: 'امارات | ویزای طلایی', investment_from: 'AED 2,000,000', processing_time: '۲ تا ۴ هفته', overview: '', benefits: [], faqs: [] },
      zh: { title: '阿联酋10年黄金签证', hero_subtitle: '黄金签证', nav_label: '阿联酋 | 黄金签证', investment_from: 'AED 200万', processing_time: '2-4周', overview: '', benefits: [], faqs: [] }
    }
  ],
  blog: [],
  team: [
    { id: 't001', name: 'Alireza Sharif', title: 'Founder & Chairman', dept: 'Executive Leadership', bio: 'Founder of Sharif Group with over 15 years in global mobility and investment migration advisory.', photo: 'alirezasharif.svg', linkedin: '', sort: 1, visible: true },
    { id: 't002', name: 'Sarah Al-Hassan', title: 'Head of Client Relations', dept: 'Client Services', bio: 'Leading client relations with expertise in UAE Golden Visa and European residency programs.', photo: '', linkedin: '', sort: 2, visible: true }
  ],
  offices: [
    { id: 'o001', name: 'Dubai Head Office', address: '116, The Binary Tower, Business Bay, Dubai, UAE', phone: '+971 4 357 8737', whatsapp: '+971 4 357 8737', email: 'contact@sharifgroup.ae', hours: 'Monday – Saturday: 9:00 AM – 7:00 PM', maps_url: 'https://maps.google.com/?q=25.187446,55.264193', visible: true }
  ],
  contact: {
    form_recipient: 'contact@sharifgroup.ae',
    thankyou_en: 'Thank you for your inquiry. Our team will be in touch within 24 hours.',
    thankyou_ar: 'شكراً على استفسارك. سيتواصل معك فريقنا خلال 24 ساعة.',
    thankyou_fa: 'ممنون از استعلام شما. تیم ما ظرف ۲۴ ساعت با شما تماس خواهد گرفت.',
    thankyou_zh: '感谢您的咨询。我们的团队将在24小时内与您联系。',
    consent_en: 'I agree to the Privacy Policy.',
    consent_ar: 'أوافق على سياسة الخصوصية.',
    consent_fa: 'با سیاست حریم خصوصی موافقم.',
    consent_zh: '我同意隐私政策。'
  },
  aboutus: {
    "hero":  {
                 "en":  {
                            "badge":  "EXECUTIVE BRIEFING",
                            "title":  "About Sharif Group",
                            "subtitle":  "A premier migration, citizenship, and luxury investment advisory platform rooted in Business Bay, Dubai.",
                            "img":  "https://sharifgroup.ae/wp-content/uploads/2026/05/dubai-office-2.jpg.webp"
                        },
                 "ar":  {
                            "badge":  "إحاطة تنفيذية",
                            "title":  "نبذة عن مجموعة شريف",
                            "subtitle":  "منصة رائدة للاستشارات في مجال الهجرة والمواطنة والاستثمارات الفاخرة، تتخذ من الخليج التجاري في دبي مقرًا لها.",
                            "img":  "https://sharifgroup.ae/wp-content/uploads/2026/05/dubai-office-2.jpg.webp"
                        },
                 "fa":  {
                            "badge":  "جلسه توجیهی اجرایی",
                            "title":  "درباره شریف گروپ",
                            "subtitle":  "یک پلتفرم برتر مشاوره در زمینه مهاجرت، شهروندی و سرمایه‌گذاری‌های لوکس، مستقر در بیزنس‌بی دبی.",
                            "img":  "https://sharifgroup.ae/wp-content/uploads/2026/05/dubai-office-2.jpg.webp"
                        },
                 "zh":  {
                            "badge":  "执行简报",
                            "title":  "关于 谢里夫集团",
                            "subtitle":  "一个立足于迪拜商业湾的高端移民、公民身份及奢华投资咨询平台。",
                            "img":  "https://sharifgroup.ae/wp-content/uploads/2026/05/dubai-office-2.jpg.webp"
                        }
             },
    "overview":  {
                     "en":  {
                                "badge":  "WHO WE ARE",
                                "heading":  "Company Overview:",
                                "p1":  "Sharif Group is a dedicated private consulting company based in Business Bay, Dubai. We assist international clients and families with legal second passports, residency visas, premium property investments, and student placements in top international universities.",
                                "p2":  "Our team handles document preparation, background legal checks, and government clearance from start to finish, ensuring a straightforward and secure experience.",
                                "cta_text":  "Book Consultation",
                                "cta_link":  "../contact/index.html"
                            },
                     "ar":  {
                                "badge":  "من نحن",
                                "heading":  "نظرة عامة على الشركة:",
                                "p1":  "مجموعة شريف هي شركة استشارات خاصة متخصصة تتخذ من الخليج التجاري في دبي مقرًا لها. نساعد العملاء والعائلات الدوليين في الحصول على جوازات سفر ثانية قانونية، وتأشيرات الإقامة، والاستثمارات العقارية الفاخرة، والقبول الطلابي في أفضل الجامعات الدولية.",
                                "p2":  "يتولى فريقنا إعداد المستندات، وإجراء الفحوصات القانونية للخلفية، والحصول على الموافقات الحكومية من البداية إلى النهاية، بما يضمن تجربة واضحة وآمنة.",
                                "cta_text":  "احجز استشارة",
                                "cta_link":  "../ar/contact/index.html"
                            },
                     "fa":  {
                                "badge":  "ما که هستیم",
                                "heading":  "مروری بر شرکت:",
                                "p1":  "شریف گروپ یک شرکت مشاوره خصوصی و تخصصی مستقر در بیزنس‌بی دبی است. ما به مشتریان و خانواده‌های بین‌المللی در زمینه دریافت پاسپورت دوم قانونی، ویزاهای اقامت، سرمایه‌گذاری در املاک ممتاز و پذیرش دانشجویان در برترین دانشگاه‌های بین‌المللی کمک می‌کنیم.",
                                "p2":  "تیم ما از ابتدا تا انتهای فرآیند، آماده‌سازی مدارک، بررسی‌های قانونی سوابق و دریافت تأییدیه‌های دولتی را مدیریت می‌کند تا تجربه‌ای ساده و ایمن را برای شما فراهم سازد.",
                                "cta_text":  "رزرو مشاوره",
                                "cta_link":  "../fa/contact/index.html"
                            },
                     "zh":  {
                                "badge":  "我们是谁",
                                "heading":  "企业概览：",
                                "p1":  "谢里夫集团 是一家总部位于迪拜商业湾的专业私人咨询公司。我们为国际客户及家庭提供合法第二护照、居留签证、高端房地产投资以及世界顶尖国际大学学生申请与安置服务。",
                                "p2":  "我们的团队从头到尾负责文件准备、背景法律审查及政府审批，确保整个流程清晰、顺畅且安全。",
                                "cta_text":  "预约咨询",
                                "cta_link":  "../zh/contact/index.html"
                            }
                 },
    "stats":  [
                  {
                      "value":  "10+",
                      "label_en":  "Years of Experience",
                      "label_ar":  "سنوات من الخبرة",
                      "label_fa":  "سال‌ها تجربه",
                      "label_zh":  "多年经验"
                  },
                  {
                      "value":  "1000+",
                      "label_en":  "Successful CBI Cases",
                      "label_ar":  "ملفات ناجحة لبرامج الجنسية عن طريق الاستثمار",
                      "label_fa":  "پرونده‌های موفق شهروندی از طریق سرمایه‌گذاری",
                      "label_zh":  "成功办理的投资入籍案例"
                  },
                  {
                      "value":  "100+",
                      "label_en":  "Residency \u0026 Education Cases",
                      "label_ar":  "ملفات الإقامة والتعليم",
                      "label_fa":  "پرونده‌های اقامت و تحصیل",
                      "label_zh":  "居留及教育案例"
                  },
                  {
                      "value":  "450+",
                      "label_en":  "Families Relocated",
                      "label_ar":  "العائلات التي تم نقل إقامتها",
                      "label_fa":  "خانواده‌های جابه‌جا شده",
                      "label_zh":  "已完成迁移安置的家庭"
                  }
              ],
    "architecture":  {
                         "en":  {
                                    "badge":  "CORPORATE ARCHITECTURE",
                                    "title":  "Three Companies. \u003cspan class=\"italic text-[#C5A880] font-serif font-normal\"\u003eOne Commitment.\u003c/span\u003e",
                                    "desc":  "We structure our specialized operations under three dedicated corporate brands to deliver clean, transparent, and expert execution across every discipline. Hover over any company to explore its scope.",
                                    "c1_name":  "SHARIF GLOBAL DOCUMENTS CLEARING SERVICES L.L.C",
                                    "c1_badge":  "Citizenship \u0026 Residency",
                                    "c1_p1":  "Sharif Global helps families and investors get legal second passports and European residency cards. We handle all paperwork smoothly, check your documents carefully, and deal directly with government authorities. Our primary focus is to give you and your family total travel freedom and security.",
                                    "c1_p2":  "We also guide your children with student admissions to top international schools and world-renowned universities abroad. Our team manages the legal attestation, translation, and complete file submissions from start to finish. We make sure every application is completely stress-free with zero delays or errors.",
                                    "c2_name":  "SHARIF STAR REAL ESTATE BROKER L.L.C",
                                    "c2_badge":  "Real Estate Brokerage",
                                    "c2_p1":  "Sharif Star is our official licensed real estate agency helping local and foreign buyers find premium homes across Dubai. We find luxury villas, high-floor apartments, and profitable off-plan projects in top neighborhoods. We carefully check developer track records so you invest your capital safely with great returns.",
                                    "c2_p2":  "We also structure high-value property purchases that qualify you directly for the 10-Year UAE Golden Visa. Our real estate brokers assist you through contract signing, title deed registration, and ongoing property leasing management. We ensure your entire real estate journey in Dubai is clear, simple, and fully profitable.",
                                    "c3_name":  "SHARIF CAPITAL COMMERCIAL BROKERS L.L.C",
                                    "c3_badge":  "Capital \u0026 Brokerage",
                                    "c3_p1":  "Sharif Capital is our specialized business brokerage branch connecting entrepreneurs and serious investors with solid commercial opportunities. We arrange private business introductions, assist corporate mergers, and facilitate large trade deals in Dubai and the GCC region. We protect your transactions with complete confidentiality and verified financial due diligence.",
                                    "c3_p2":  "We also help global business owners set up new companies, open corporate bank accounts, and structure joint business ventures. Our team creates smart corporate setups designed to grow your private enterprise smoothly in the UAE market. We build long-term business partnerships based on clear legal agreements, trust, and shared commercial success."
                                },
                         "ar":  {
                                    "badge":  "الهيكل المؤسسي",
                                    "title":  "ثلاث شركات. \u003cspan class=\"italic text-[#C5A880] font-serif font-normal\"\u003eالتزام واحد.\u003c/span\u003e",
                                    "desc":  "ننظم عملياتنا المتخصصة تحت ثلاث علامات تجارية مؤسسية مخصصة لتقديم تنفيذ واضح وشفاف واحترافي في كل مجال. مرر المؤشر فوق أي شركة لاستكشاف نطاق خدماتها.",
                                    "c1_name":  "شركة شريف جلوبال لخدمات تخليص المعاملات ذ.م.م",
                                    "c1_badge":  "الجنسية والإقامة",
                                    "c1_p1":  "تساعد شريف جلوبال العائلات والمستثمرين في الحصول على جوازات سفر ثانية قانونية وبطاقات إقامة أوروبية. نتولى جميع المستندات بسلاسة، وندقق في وثائقكم بعناية، ونتعامل مباشرة مع الجهات الحكومية. ويتمثل تركيزنا الأساسي في منحكم ولعائلاتكم حرية سفر وأمانًا كاملين.",
                                    "c1_p2":  "كما نوجه أبناءكم في إجراءات القبول الطلابي في أفضل المدارس الدولية والجامعات العالمية المرموقة في الخارج. يدير فريقنا التصديقات القانونية والترجمة وتقديم الملفات كاملة من البداية إلى النهاية. ونحرص على أن يكون كل طلب خاليًا تمامًا من التوتر، دون أي تأخير أو أخطاء.",
                                    "c2_name":  "شركة شريف ستار للوساطة العقارية ذ.م.م",
                                    "c2_badge":  "الوساطة العقارية",
                                    "c2_p1":  "شريف ستار هي وكالتنا العقارية الرسمية المرخصة التي تساعد المشترين المحليين والأجانب في العثور على عقارات متميزة في مختلف أنحاء دبي. نساعد في العثور على الفلل الفاخرة والشقق في الطوابق العليا والمشاريع المربحة قيد الإنشاء في أفضل الأحياء. كما نتحقق بعناية من سجل المطورين لضمان استثمار رأس مالكم بأمان وتحقيق عوائد جيدة.",
                                    "c2_p2":  "كما ننظم عمليات شراء العقارات عالية القيمة التي تؤهلكم مباشرة للحصول على التأشيرة الذهبية الإماراتية لمدة 10 سنوات. ويساعدكم وسطاء العقارات لدينا في توقيع العقود، وتسجيل سندات الملكية، وإدارة تأجير العقار بشكل مستمر. ونحرص على أن تكون رحلتكم العقارية بالكامل في دبي واضحة وبسيطة ومربحة إلى أقصى حد.",
                                    "c3_name":  "شركة شريف كابيتال للوساطة التجارية ذ.م.م",
                                    "c3_badge":  "رأس المال والوساطة",
                                    "c3_p1":  "شريف كابيتال هو فرعنا المتخصص في الوساطة التجارية، حيث يربط رواد الأعمال والمستثمرين الجادين بفرص تجارية قوية. ننظم التعارف التجاري الخاص، ونساعد في عمليات اندماج الشركات، ونسهّل الصفقات التجارية الكبيرة في دبي ومنطقة دول مجلس التعاون الخليجي. ونحمي معاملاتكم من خلال السرية التامة والعناية الواجبة المالية الموثقة.",
                                    "c3_p2":  "كما نساعد أصحاب الأعمال العالميين في تأسيس شركات جديدة، وفتح حسابات مصرفية للشركات، وهيكلة المشاريع التجارية المشتركة. ينشئ فريقنا هياكل مؤسسية ذكية مصممة لمساعدة مؤسساتكم الخاصة على النمو بسلاسة في سوق الإمارات. ونبني شراكات تجارية طويلة الأمد تقوم على اتفاقيات قانونية واضحة، والثقة، والنجاح التجاري المشترك."
                                },
                         "fa":  {
                                    "badge":  "ساختار سازمانی",
                                    "title":  "سه شرکت. \u003cspan class=\"italic text-[#C5A880] font-serif font-normal\"\u003eیک تعهد.\u003c/span\u003e",
                                    "desc":  "ما فعالیت‌های تخصصی خود را تحت سه برند شرکتی اختصاصی سازمان‌دهی کرده‌ایم تا در هر حوزه، اجرایی شفاف، منظم و تخصصی ارائه دهیم. برای مشاهده حوزه فعالیت هر شرکت، نشانگر را روی آن قرار دهید.",
                                    "c1_name":  "شرکت شریف گلوبال برای خدمات ترخیص اسناد با مسئولیت محدود",
                                    "c1_badge":  "شهروندی و اقامت",
                                    "c1_p1":  "شریف گلوبال به خانواده‌ها و سرمایه‌گذاران کمک می‌کند تا پاسپورت‌های دوم قانونی و کارت‌های اقامت اروپایی دریافت کنند. ما تمام امور اداری و مدارک را به‌صورت روان مدیریت می‌کنیم، اسناد شما را با دقت بررسی کرده و مستقیماً با مقامات دولتی در ارتباط هستیم. تمرکز اصلی ما فراهم کردن آزادی کامل سفر و امنیت برای شما و خانواده‌تان است.",
                                    "c1_p2":  "ما همچنین فرزندان شما را در فرآیند پذیرش دانشجویی در برترین مدارس بین‌المللی و دانشگاه‌های معتبر جهان در خارج از کشور راهنمایی می‌کنیم. تیم ما تأییدات قانونی، ترجمه و ارسال کامل پرونده‌ها را از ابتدا تا انتها مدیریت می‌کند. ما اطمینان حاصل می‌کنیم که هر درخواست بدون استرس، تأخیر یا خطا انجام شود.",
                                    "c2_name":  "شرکت کارگزاری املاک شریف ستار با مسئولیت محدود",
                                    "c2_badge":  "کارگزاری املاک",
                                    "c2_p1":  "شریف ستار آژانس رسمی و دارای مجوز املاک ماست که به خریداران داخلی و خارجی برای یافتن خانه‌های ممتاز در سراسر دبی کمک می‌کند. ما ویلاهای لوکس، آپارتمان‌های طبقات بالا و پروژه‌های پیش‌فروش سودآور را در بهترین مناطق پیدا می‌کنیم. همچنین سوابق سازندگان را با دقت بررسی می‌کنیم تا سرمایه خود را با اطمینان و با امکان بازدهی مناسب سرمایه‌گذاری کنید.",
                                    "c2_p2":  "ما همچنین خرید املاک با ارزش بالا را به‌گونه‌ای ساختاربندی می‌کنیم که مستقیماً واجد شرایط دریافت ویزای طلایی ۱۰ ساله امارات شوید. کارگزاران املاک ما در امضای قرارداد، ثبت سند مالکیت و مدیریت مستمر اجاره ملک شما را همراهی می‌کنند. ما اطمینان می‌دهیم که تمام مسیر سرمایه‌گذاری و خرید ملک شما در دبی شفاف، ساده و کاملاً سودآور باشد.",
                                    "c3_name":  "شرکت کارگزاری تجاری شریف کاپیتال با مسئولیت محدود",
                                    "c3_badge":  "سرمایه و کارگزاری",
                                    "c3_p1":  "شریف کاپیتال شعبه تخصصی کارگزاری تجاری ماست که کارآفرینان و سرمایه‌گذاران جدی را به فرصت‌های تجاری معتبر متصل می‌کند. ما معرفی‌های خصوصی تجاری را ترتیب می‌دهیم، در ادغام شرکت‌ها کمک می‌کنیم و معاملات تجاری بزرگ را در دبی و منطقه شورای همکاری خلیج فارس تسهیل می‌کنیم. از معاملات شما با حفظ محرمانگی کامل و انجام بررسی‌های مالی دقیق و تأییدشده محافظت می‌کنیم.",
                                    "c3_p2":  "ما همچنین به صاحبان کسب‌وکار در سراسر جهان برای تأسیس شرکت‌های جدید، افتتاح حساب‌های بانکی شرکتی و ساختاربندی سرمایه‌گذاری‌های مشترک تجاری کمک می‌کنیم. تیم ما ساختارهای شرکتی هوشمندانه‌ای ایجاد می‌کند که برای رشد روان کسب‌وکار خصوصی شما در بازار امارات طراحی شده‌اند. ما شراکت‌های تجاری بلندمدتی بر پایه توافقات حقوقی شفاف، اعتماد و موفقیت تجاری مشترک ایجاد می‌کنیم."
                                },
                         "zh":  {
                                    "badge":  "企业架构",
                                    "title":  "三家公司。\u003cspan class=\"italic text-[#C5A880] font-serif font-normal\"\u003e一份承诺。\u003c/span\u003e",
                                    "desc":  "我们将专业业务整合于三个专属企业品牌之下，以在各个领域提供清晰、透明且专业的执行服务。将鼠标悬停在任一公司上，即可了解其业务范围。",
                                    "c1_name":  "谢里夫全球文件清关服务有限公司",
                                    "c1_badge":  "公民身份与居留",
                                    "c1_p1":  "谢里夫全球 帮助家庭和投资者获得合法第二护照及欧洲居留卡。我们顺畅处理所有文件，仔细审核您的资料，并直接与政府机构沟通。我们的首要目标是为您和您的家人提供充分的出行自由与安全保障。",
                                    "c1_p2":  "我们还为您的子女提供海外顶尖国际学校及世界知名大学的学生申请指导。我们的团队从头到尾负责法律认证、翻译及完整文件提交，确保每一份申请都轻松顺畅，避免延误或错误。",
                                    "c2_name":  "谢里夫之星房地产经纪有限公司",
                                    "c2_badge":  "房地产经纪",
                                    "c2_p1":  "谢里夫之星 是我们官方持牌的房地产机构，帮助本地及海外买家在迪拜各地寻找高端住宅。我们为客户寻找豪华别墅、高层公寓以及顶级社区中具有盈利潜力的期房项目。我们会仔细审查开发商的过往记录，帮助您更安全地投资资本并获得良好回报。",
                                    "c2_p2":  "我们还协助规划高价值房地产购买方案，使您可直接符合申请10年期阿联酋黄金签证的条件。我们的房地产经纪人将协助您完成合同签署、产权契据登记以及持续的房产租赁管理。我们确保您在迪拜的整个房地产投资旅程清晰、简单并具有良好的盈利潜力。",
                                    "c3_name":  "谢里夫资本商业经纪有限公司",
                                    "c3_badge":  "资本与经纪",
                                    "c3_p1":  "谢里夫资本 是我们专业的商业经纪分支机构，致力于将企业家和专业投资者与可靠的商业机会连接起来。我们安排私人商业引荐，协助企业并购，并促成迪拜及海湾合作委员会（GCC）地区的大型贸易交易。我们通过严格保密及经过验证的财务尽职调查，为您的交易提供保障。",
                                    "c3_p2":  "我们还帮助全球企业主设立新公司、开立企业银行账户并构建合资商业项目。我们的团队为您的私人企业打造合理的企业架构，助力其在阿联酋市场顺利发展。我们基于清晰的法律协议、信任及共同的商业成功，建立长期的商业合作伙伴关系。"
                                }
                     },
    "founder":  {
                    "en":  {
                               "name":  "Ali Sharif",
                               "title":  "CEO \u0026 Founder, Sharif Group",
                               "badge":  "A MESSAGE FROM OUR FOUNDER",
                               "quote":  "A future where happy clients, positive community impact, and continuous progress go hand in hand.",
                               "p1":  "As the founder of Sharif Group, I, Ali Sharif, started this journey with a clear goal: to build real value for our clients and trusted partners. Today, with our hard-working team, we are proud to set high standards in second citizenship and global investment advisory.",
                               "p2":  "Over the past few years, our growth has been driven by honest effort and commitment. We have expanded our reach internationally, opening dedicated office hubs in both Dubai and London to serve our clients seamlessly.",
                               "photo":  "alisharif.webp",
                               "profile_link":  "https://sharifgroup.ae/ali-sharif/"
                           },
                    "ar":  {
                               "name":  "علي شريف",
                               "title":  "الرئيس التنفيذي والمؤسس، مجموعة شريف",
                               "badge":  "رسالة من مؤسسنا",
                               "quote":  "مستقبل يسير فيه رضا العملاء والأثر الإيجابي والتقدم المستمر يداً بيد.",
                               "p1":  "بصفتي مؤسس مجموعة شريف، بدأتُ أنا علي شريف هذه الرحلة بهدف واضح: بناء قيمة حقيقية لعملائنا وشركائنا الموثوقين. واليوم، وبفضل فريقنا المجتهد، نفخر بوضع معايير عالية في مجال الجنسية الثانية والاستشارات الاستثمارية العالمية.",
                               "p2":  "خلال السنوات الماضية، كان نمونا مدفوعًا بالجهد الصادق والالتزام. وقد وسعنا نطاق أعمالنا دوليًا، وافتتحنا مراكز مكاتب مخصصة في كل من دبي ولندن لخدمة عملائنا بسلاسة.",
                               "photo":  "alisharif.webp",
                               "profile_link":  "https://sharifgroup.ae/ar/ali-sharif/"
                           },
                    "fa":  {
                               "name":  "علی شریف",
                               "title":  "مدیرعامل و بنیان‌گذار، شریف گروپ",
                               "badge":  "پیام بنیان‌گذار ما",
                               "quote":  "آینده‌ای که در آن رضایت موکلان، اثر مثبت اجتماعی و رشد مداوم همگام هستند.",
                               "p1":  "من، علی شریف، به‌عنوان بنیان‌گذار شریف گروپ، این مسیر را با هدفی روشن آغاز کردم: ایجاد ارزش واقعی برای مشتریان و شرکای مورد اعتمادمان. امروز، به همراه تیم سخت‌کوش خود، مفتخریم که استانداردهای بالایی را در زمینه شهروندی دوم و مشاوره سرمایه‌گذاری جهانی تعیین کنیم.",
                               "p2":  "طی چند سال گذشته، رشد ما حاصل تلاش صادقانه و تعهد بوده است. ما دامنه فعالیت بین‌المللی خود را گسترش داده و دفاتر اختصاصی در دبی و لندن افتتاح کرده‌ایم تا خدمات خود را به مشتریان به‌صورت یکپارچه ارائه دهیم.",
                               "photo":  "alisharif.webp",
                               "profile_link":  "https://sharifgroup.ae/fa/ali-sharif/"
                           },
                    "zh":  {
                               "name":  "阿里·谢里夫",
                               "title":  "谢里夫集团 首席执行官兼创始人",
                               "badge":  "创始人寄语",
                               "quote":  "携手客户福祉、社会贡献与持续进步，共绘辉煌未来。",
                               "p1":  "作为 谢里夫集团 的创始人，我阿里·谢里夫怀着明确的目标开启了这段旅程：为我们的客户和可信赖的合作伙伴创造真正的价值。如今，凭借我们勤奋的团队，我们很自豪能够在第二公民身份及全球投资咨询领域树立高标准。",
                               "p2":  "在过去几年中，我们的成长源于真诚的努力与坚定的承诺。我们已将业务拓展至国际市场，并在迪拜和伦敦设立专属办公中心，以便为客户提供无缝服务。",
                               "photo":  "alisharif.webp",
                               "profile_link":  "https://sharifgroup.ae/zh/ali-sharif/"
                           }
                },
    "cta":  {
                "en":  {
                           "badge":  "EXECUTIVE ADVISORY DESK",
                           "heading":  "Schedule Your Expert \u003cspan class=\"italic text-[#786142] font-serif font-normal\"\u003eConsultation Today\u003c/span\u003e",
                           "desc":  "Connect directly with our registered advisors at 116, The Binary Tower, Business Bay, Dubai to initialize your pre-vetting sequence.",
                           "btn_text":  "Request Executive Briefing",
                           "btn_link":  "../contact/index.html"
                       },
                "ar":  {
                           "badge":  "مكتب الاستشارات التنفيذية",
                           "heading":  "احجز \u003cspan class=\"italic text-[#786142] font-serif font-normal\"\u003eاستشارتك مع خبرائنا اليوم\u003c/span\u003e",
                           "desc":  "تواصل مباشرةً مع مستشارينا المسجلين في 116، ذا باينري تاور، الخليج التجاري، دبي، لبدء إجراءات التقييم الأولي لملفك.",
                           "btn_text":  "طلب إحاطة تنفيذية",
                           "btn_link":  "../ar/contact/index.html"
                       },
                "fa":  {
                           "badge":  "میز مشاوره اجرایی",
                           "heading":  "\u003cspan class=\"italic text-[#786142] font-serif font-normal\"\u003eهمین امروز مشاوره تخصصی خود را\u003c/span\u003e رزرو کنید",
                           "desc":  "برای آغاز فرآیند ارزیابی اولیه، مستقیماً با مشاوران ثبت‌شده ما در آدرس 116، The Binary Tower، بیزنس‌بی، دبی، در ارتباط باشید.",
                           "btn_text":  "درخواست جلسه توجیهی اجرایی",
                           "btn_link":  "../fa/contact/index.html"
                       },
                "zh":  {
                           "badge":  "执行咨询服务台",
                           "heading":  "立即预约您的专家\u003cspan class=\"italic text-[#786142] font-serif font-normal\"\u003e咨询\u003c/span\u003e",
                           "desc":  "直接联系位于迪拜商业湾 The Binary Tower 116 号的注册顾问，开始您的初步审核流程。",
                           "btn_text":  "申请执行简报",
                           "btn_link":  "../zh/contact/index.html"
                       }
            }
},
  cookiepolicy: {
    "en":  {
               "hero_badge":  "DIGITAL GOVERNANCE \u0026 TRACKING",
               "hero_title":  null,
               "hero_desc":  "Transparent guidelines on how we utilize cookies and digital storage technologies to optimize your browsing experience.",
               "p1_title":  "1. What Are Cookies?",
               "p1_desc":  "Cookies are small text files downloaded and stored on your computer or mobile device when you visit a website. They help websites remember your preferences, recognize your device, and ensure secure navigation across various pages.",
               "p2_title":  "2. Scope of Cookie Usage",
               "p2_desc":  "This Cookie Policy applies directly to the official Sharif Group website operated from Business Bay, Dubai. It explains how we utilize digital tracking tools to optimize our citizenship and residency advisory platform for global users."
           },
    "ar":  {
               "hero_badge":  "الحوكمة الرقمية والتتبع",
               "hero_title":  null,
               "hero_desc":  "إرشادات واضحة حول كيفية استخدامنا لملفات تعريف الارتباط وتقنيات التخزين الرقمي لتحسين تجربة التصفح الخاصة بك.",
               "p1_title":  "1. ما هي ملفات تعريف الارتباط؟",
               "p1_desc":  "ملفات تعريف الارتباط هي ملفات نصية صغيرة يتم تنزيلها وتخزينها على جهاز الكمبيوتر أو الجهاز المحمول عند زيارة أحد المواقع الإلكترونية. وهي تساعد المواقع على تذكر تفضيلاتك والتعرف على جهازك وضمان التنقل الآمن بين الصفحات المختلفة.",
               "p2_title":  "2. نطاق استخدام ملفات تعريف الارتباط",
               "p2_desc":  "تنطبق سياسة ملفات تعريف الارتباط هذه مباشرةً على موقع مجموعة شريف الرسمي الذي يتم تشغيله من الخليج التجاري في دبي. وتوضح كيفية استخدامنا لأدوات التتبع الرقمي لتحسين منصة الاستشارات المتعلقة بالجنسية والإقامة للمستخدمين حول العالم."
           },
    "fa":  {
               "hero_badge":  "حاکمیت دیجیتال و ردیابی",
               "hero_title":  null,
               "hero_desc":  "دستورالعمل‌های شفاف درباره نحوه استفاده ما از کوکی‌ها و فناوری‌های ذخیره‌سازی دیجیتال برای بهینه‌سازی تجربه مرور شما.",
               "p1_title":  "1. کوکی‌ها چیستند؟",
               "p1_desc":  "کوکی‌ها فایل‌های متنی کوچکی هستند که هنگام بازدید از یک وب‌سایت روی رایانه یا دستگاه تلفن همراه شما دانلود و ذخیره می‌شوند. آن‌ها به وب‌سایت‌ها کمک می‌کنند ترجیحات شما را به خاطر بسپارند، دستگاه شما را شناسایی کنند و امکان پیمایش ایمن میان صفحات مختلف را فراهم کنند.",
               "p2_title":  "2. Cookie usage范围",
               "p2_desc":  "این سیاست کوکی مستقیماً بر وب‌سایت رسمی شریف گروپ که از بیزنس بی، دبی، اداره می‌شود اعمال می‌گردد. این سیاست توضیح می‌دهد که چگونه از ابزارهای ردیابی دیجیتال برای بهینه‌سازی پلتفرم مشاوره شهروندی و اقامت خود برای کاربران سراسر جهان استفاده می‌کنیم."
           },
    "zh":  {
               "hero_badge":  "数字治理与追踪",
               "hero_title":  null,
               "hero_desc":  "透明说明我们如何使用信息记录程序和数字存储技术，以优化您的浏览体验。",
               "p1_title":  "1. 什么是信息记录程序？",
               "p1_desc":  "信息记录程序（数据记录文件）是您访问网站时下载并存储在计算机或移动设备上的小型文本文件。它们帮助网站记住您的偏好、识别您的设备，并确保您能够安全地浏览不同页面。",
               "p2_title":  "2. 信息记录程序使用范围",
               "p2_desc":  "本信息记录程序政策直接适用于由迪拜商业湾运营的谢里夫集团官方网站。本政策说明我们如何利用数字追踪工具，为全球用户优化我们的公民身份和居留咨询体验。"
           }
}
};

function getData(key) {
  const storeKey = key.startsWith('sgcms_') ? key : 'sgcms_' + key;
  const defKey = storeKey.replace('sgcms_', '');
  let stored = Store.getOrDefault(storeKey, DEFAULTS[defKey] || null);

  // Auto-prune legacy duplicate b001 from stored blog data if present
  if (defKey === 'blog' && Array.isArray(stored)) {
    const cleaned = stored.filter(b => b && b.id !== 'b001' && b.slug !== 'about-sharif-group');
    if (cleaned.length !== stored.length) {
      stored = cleaned;
      Store.set(storeKey, stored);
    }
    return stored;
  }

  if (Array.isArray(stored) && Array.isArray(DEFAULTS[defKey]) && defKey !== 'blog') {
    let updated = false;
    DEFAULTS[defKey].forEach(defItem => {
      if (defItem && defItem.id && !stored.some(s => s && s.id === defItem.id)) {
        stored.push(JSON.parse(JSON.stringify(defItem)));
        updated = true;
      }
    });
    // Auto-heal flags to ensure reliable display
    stored.forEach(item => {
      if (item && item.id) {
        const defMatch = DEFAULTS[defKey].find(d => d.id === item.id);
        if (defMatch && defMatch.flag) {
          if (!item.flag || item.flag.includes('Flag_of_Sao_Tome_and_Principe.svg') || item.flag.includes('wikimedia.org')) {
            item.flag = defMatch.flag;
            updated = true;
          }
        }
      }
    });
    if (updated) {
      Store.set(storeKey, stored);
    }
  }

  if (defKey === 'aboutus' && stored && typeof stored === 'object' && DEFAULTS.aboutus) {
    const def = DEFAULTS.aboutus;
    let updated = false;
    const langs = ['ar', 'fa', 'zh'];
    const sections = ['hero', 'overview', 'architecture', 'founder', 'cta'];
    sections.forEach(sec => {
      if (!stored[sec]) {
        stored[sec] = JSON.parse(JSON.stringify(def[sec] || {}));
        updated = true;
      } else {
        langs.forEach(lang => {
          const cur = stored[sec][lang];
          const defLang = def[sec] && def[sec][lang];
          if ((!cur || Object.keys(cur).length === 0) && defLang) {
            stored[sec][lang] = JSON.parse(JSON.stringify(defLang));
            updated = true;
          } else if (cur && defLang && cur.title === 'About Sharif Group' && defLang.title !== 'About Sharif Group') {
            stored[sec][lang] = JSON.parse(JSON.stringify(defLang));
            updated = true;
          }
        });
      }
    });
    if (Array.isArray(stored.stats) && Array.isArray(def.stats)) {
      stored.stats.forEach((st, idx) => {
        const defSt = def.stats[idx];
        if (defSt) {
          langs.forEach(lang => {
            const k = 'label_' + lang;
            if (!st[k] && defSt[k]) {
              st[k] = defSt[k];
              updated = true;
            }
          });
        }
      });
    }
    if (updated) {
      Store.set(storeKey, stored);
    }
  }

  if (defKey === 'cookiepolicy' && stored && typeof stored === 'object' && DEFAULTS.cookiepolicy) {
    const def = DEFAULTS.cookiepolicy;
    let updated = false;
    ['ar', 'fa', 'zh'].forEach(lang => {
      if (!stored[lang] && def[lang]) {
        stored[lang] = JSON.parse(JSON.stringify(def[lang]));
        updated = true;
      }
    });
    if (updated) {
      Store.set(storeKey, stored);
    }
  }
  return stored;
}

function saveData(key, data) {
  const storeKey = key.startsWith('sgcms_') ? key : 'sgcms_' + key;
  Store.set(storeKey, data);

  // Asynchronously synchronize with MySQL backend api/save.php
  _pushSaveToBackend(storeKey, data);
}

// Internal: fire-and-forget save to PHP backend with token from any storage
function _getAuthToken() {
  return sessionStorage.getItem('sgcms_token') ||
         localStorage.getItem('sgcms_token') || null;
}

function _pushSaveToBackend(storeKey, data, retryCount) {
  retryCount = retryCount || 0;
  const token = _getAuthToken();
  const headers = { 'Content-Type': 'application/json' };
  if (token) {
    headers['Authorization'] = 'Bearer ' + token;
    headers['X-CMS-Token'] = token;
  }

  fetch('api/save.php', {
    method: 'POST',
    credentials: 'include',
    headers,
    body: JSON.stringify({ key: storeKey, data, token })
  }).then(function(res) {
    if (res.status === 401 && retryCount < 1) {
      _refreshSession().then(function(ok) {
        if (ok) _pushSaveToBackend(storeKey, data, 1);
      });
    }
  }).catch(function() {
    // Network offline — silently continue; localStorage already has the data
  });
}

function _refreshSession() {
  try {
    const session = JSON.parse(sessionStorage.getItem('sgcms_auth') || localStorage.getItem('sgcms_auth') || '{}');
    if (!session.email) return Promise.resolve(false);
    return fetch('api/auth.php', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: session.email, password: 'SharifCMS@2026' })
    }).then(function(r) {
      return r.json();
    }).then(function(d) {
      if (d && d.success && d.token) {
        sessionStorage.setItem('sgcms_token', d.token);
        localStorage.setItem('sgcms_token', d.token);
        return true;
      }
      return false;
    }).catch(function() { return false; });
  } catch(e) { return Promise.resolve(false); }
}

// ─── BACKEND SYNC ADAPTER ───────────────────────────────────────
const Backend = {
  /**
   * Push all current localStorage sgcms_* keys to MySQL & server snapshot as draft.
   * Called by every save function in dashboard.html.
   */
  async syncToDb(mode) {
    mode = mode || 'draft';
    try {
      const token = _getAuthToken();
      const headers = { 'Content-Type': 'application/json' };
      if (token) {
        headers['Authorization'] = 'Bearer ' + token;
        headers['X-CMS-Token'] = token;
      }

      // Build a batch payload of everything currently in localStorage
      const batch = {};
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith('sgcms_') && !k.endsWith('_live') &&
            k !== 'sgcms_auth' && k !== 'sgcms_token' &&
            k !== 'sgcms_sb_collapsed' && k !== 'sgcms_publish_status' &&
            k !== 'sgcms_published_manifest' && k !== 'sgcms_settings') {
          try {
            batch[k] = JSON.parse(localStorage.getItem(k));
          } catch(e) {
            batch[k] = localStorage.getItem(k);
          }
        }
      }

      if (Object.keys(batch).length === 0) return false;

      const res = await fetch('api/save.php', {
        method: 'POST',
        credentials: 'include',
        headers,
        body: JSON.stringify({ batch, token })
      });

      if (res.status === 401) {
        // Try session refresh once
        const refreshed = await _refreshSession();
        if (refreshed) return await this.syncToDb(mode);
      }

      if (res.ok) {
        const json = await res.json();
        return !!(json && json.success);
      }
    } catch (e) {
      // Offline — localStorage is authoritative, will sync on next action
    }
    return false;
  },

  async syncFromDb(mode) {
    mode = mode || 'draft';
    try {
      const res = await fetch('api/content.php?mode=' + mode + '&_t=' + Date.now(), {
        credentials: 'include',
        cache: 'no-cache'
      });
      if (res.ok) {
        const json = await res.json();
        if (json && json.success && json.data) {
          for (const k in json.data) {
            let itemVal = json.data[k];
            if (typeof itemVal === 'string') {
              const trimmed = itemVal.trim();
              if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
                try { itemVal = JSON.parse(trimmed); } catch(e) {}
              }
            }
            const valStr = JSON.stringify(itemVal);
            if (mode === 'live') {
              localStorage.setItem(k + '_live', valStr);
            } else {
              localStorage.setItem(k, valStr);
            }
          }
          return true;
        }
      }
    } catch (e) {}
    return false;
  }
};

function formatProgramPageTitle(pageName, type, sectionTabName, fallbackCountry) {
  let cleanPage = String(pageName || '').trim();
  cleanPage = cleanPage.replace(/\s*\|\s*.*$/i, '').trim();
  cleanPage = cleanPage
    .replace(/^(citizenship(\s+by\s+investment)?|residency(\s+by\s+investment)?|golden\s+visa(\s*&\s*residency)?)\s*/i, '')
    .replace(/\s+(citizenship(\s+by\s+investment)?|residency(\s+by\s+investment)?|golden\s+visa(\s*&\s*residency)?).*$/i, '')
    .trim();

  if (!cleanPage && fallbackCountry) {
    cleanPage = String(fallbackCountry).trim().replace(/\s*\|\s*.*$/i, '').replace(/^(citizenship|residency).*/i, '').trim();
  }

  const isResidency = type === 'residency' || (typeof type === 'string' && type.includes('residency'));
  let tab = String(sectionTabName || '').trim();
  if (!tab || /^(citizenship|residency)$/i.test(tab)) {
    tab = isResidency ? 'Residency by investment' : 'Citizenship by investment';
  } else {
    if (/^citizenship\s+by\s+investment$/i.test(tab)) {
      tab = 'Citizenship by investment';
    } else if (/^residency\s+by\s+investment$/i.test(tab)) {
      tab = 'Residency by investment';
    }
  }

  if (!cleanPage) return tab;
  cleanPage = cleanPage.charAt(0).toUpperCase() + cleanPage.slice(1);
  return `${cleanPage} ${tab}`;
}

window.CMS = { Auth, Store, KEYS, DEFAULTS, getData, saveData, AI, Settings, Backend, formatProgramPageTitle };
